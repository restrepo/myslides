
INSPIREfetcher - Plugin
---------------------------------------

Fetch database entries from INSPIRE.

Author
  * Christoph Lehner (clehner // users.sourceforge.net)

Build instructions:
  * Run build.xml with target jars (default)
  
Changelog: 

  * 2011-09-23 - V0.1 - Initial release.

  * 2011-09-26 - V0.2 - Do not add leading "find" to search
                        automatically.

  * 2011-10-12 - V0.3 - New host inspirehep.net; Fetch up
                        to 100 entries.
